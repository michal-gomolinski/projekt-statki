package StatkiKlient;

import javax.swing.*;
import javax.swing.text.SimpleAttributeSet;
import javax.swing.text.StyleConstants;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;


public class Frame extends JFrame implements ActionListener {

    JButton graj;
    JButton wylacz;
    JButton rozdzielczosc;
    JButton credits;

    JButton menu;
    JButton rozlacz;

    JTextPane tytul;

    JPanel plansza;

    final String dostepneRozdzielczoscStr[] = new String[]{"800x600", "1000x750", "1200x900"};;
    final int  dostepneRozdzielczosciSzerokosc[] = new int[]{800,1000,1200};
    final int  dostepneRozdzielczosciWysokosc[] = new int[]{600,750,900};
    int wybranaRozdzielczosc = 0;

    void zacznijGre(){
        remove(graj);
        remove(wylacz);
        remove(rozdzielczosc);
        remove(credits);
        remove(tytul);

        add(menu);
        add(rozlacz);

        setBackground(Color.white);

        plansza = new RysujPlansze();
        pack();
        plansza.setSize(this.getContentPane().getSize());
        add(plansza);

        repaint();
    }

    void ustawRozdzielczosc(){
        setPreferredSize(new Dimension(dostepneRozdzielczosciSzerokosc[wybranaRozdzielczosc],dostepneRozdzielczosciWysokosc[wybranaRozdzielczosc]));
        pack();


        tytul.setBounds(10,10,getContentPane().getWidth() - 20,getContentPane().getHeight()/4);

        SimpleAttributeSet attribs = new SimpleAttributeSet();
        StyleConstants.setAlignment(attribs, StyleConstants.ALIGN_CENTER);
        StyleConstants.setBackground(attribs,Color.darkGray);
        StyleConstants.setFontSize(attribs,getContentPane().getHeight()/7);
        tytul.setEditable(false);
        tytul.setParagraphAttributes(attribs, true);

        graj.setBounds(10, getContentPane().getHeight()/3, getContentPane().getWidth() - 20, getContentPane().getHeight()/6);
        rozdzielczosc.setBounds(10, getContentPane().getHeight()/2, getContentPane().getWidth() - 20, getContentPane().getHeight()/6);
        credits.setBounds(10, getContentPane().getHeight()/6*4, getContentPane().getWidth() - 20, getContentPane().getHeight()/6);
        wylacz.setBounds(10, getContentPane().getHeight()/6 * 5, getContentPane().getWidth() - 20, getContentPane().getHeight()/6);
        menu.setBounds(getContentPane().getWidth()/2 - 75, 100, 150, 20);
        rozlacz.setBounds(getContentPane().getWidth()/2 - 75, 130, 150, 20);

    }

    void menuGlowne(){
        pack();

        tytul.setText("PROJEKT STATKI");
        add(tytul);

        add(graj);
        add(rozdzielczosc);
        add(credits);
        add(wylacz);

    }

    void powrot(){
        remove(menu);
        remove(plansza);
        remove(rozlacz);

        menuGlowne();
        repaint();
    }

    public Frame() {
        setTitle("Statki");
        setPreferredSize(new Dimension(dostepneRozdzielczosciSzerokosc[wybranaRozdzielczosc],dostepneRozdzielczosciWysokosc[wybranaRozdzielczosc]));
        setResizable(false);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(null);

        tytul = new JTextPane();
        graj = new JButton("Graj");
        rozdzielczosc = new JButton("Opcje");
        credits = new JButton("Credits");
        wylacz = new JButton("Wyłącz");
        menu = new JButton("Menu");
        rozlacz = new JButton("Rozłącz");

        graj.addActionListener(this);
        rozdzielczosc.addActionListener(this);
        credits.addActionListener(this);
        wylacz.addActionListener(this);
        menu.addActionListener(this);



        menuGlowne();
        ustawRozdzielczosc();

        setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        Object source = e.getSource();

        if(source == graj)
            zacznijGre();
        if(source == wylacz)
            System.exit(0);
        if(source == credits)
            JOptionPane.showMessageDialog(this, "Wykonał:\nMichał Gomoliński\nWCY18IY1S1");
        if(source == menu)
            powrot();
        if(source == rozdzielczosc){
            String rozd = (String)JOptionPane.showInputDialog(this,"Wybierz Rozdzielczość:","Rozdzielczość",JOptionPane.QUESTION_MESSAGE,null,dostepneRozdzielczoscStr,"");
            for(int i = 0;i < 3;i++){
                if(rozd.equals(dostepneRozdzielczoscStr[i]))
                    wybranaRozdzielczosc = i;
                ustawRozdzielczosc();
            }

        }
    }
}
