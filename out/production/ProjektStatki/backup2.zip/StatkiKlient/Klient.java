package StatkiKlient;

import java.net.*;
import java.io.*;


public class Klient extends Thread{
    Plansza planszaKomputera;
    Plansza planszaGracza;
    RysujPlansze plansza;
    DataInputStream in;
    Socket socket;

    Klient(Plansza planszaKomputera, Plansza planszaGracza, Socket socket,RysujPlansze plansza){
        this.planszaKomputera = planszaKomputera;
        this.planszaGracza = planszaGracza;
        this.socket = socket;
        this.plansza = plansza;
    }


    @Override
    public void run() {

        while(planszaKomputera.iloscStatkow != 10) {
                try {
                    in = new DataInputStream(socket.getInputStream());
                    int cord = in.readInt();
                    System.out.println(cord);
                    System.out.println((cord/10)+" "+(cord%10));
                    plansza.przeciwnikOstatniRuch = planszaKomputera.atak(cord/10,cord%10,planszaGracza);
                    plansza.repaint();
                } catch (IOException e) {
                }
                    planszaGracza.ruch = 1;


        }




    }

}
