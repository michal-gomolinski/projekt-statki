package StatkiKlient;

import java.util.TimerTask;

public class Repaint extends TimerTask {
    RysujPlansze rysujPlansze;
    Repaint(RysujPlansze rysujPlansze){
        this.rysujPlansze = rysujPlansze;
    }



    @Override
    public void run() {
        rysujPlansze.repaint();
    }
}
