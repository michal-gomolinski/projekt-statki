package StatkiKlient;

import javax.swing.*;
import javax.swing.border.Border;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.geom.Ellipse2D;
import java.awt.geom.Line2D;
import java.io.*;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Timer;

import static javax.swing.JOptionPane.*;


public class RysujPlansze extends JPanel implements MouseListener , ActionListener {

    Plansza planszaGracz;
    volatile Plansza planszaPrzeciwnik;

    JButton poziomoButton;
    JButton wybierzJedenMaszt;
    JButton wybierzDwaMaszt;
    JButton wybierzTrzyMaszt;
    JButton wybierzCzteryMaszt;

    JButton reset;
    JButton single;
    JButton multi;
    JButton wyjdz;

    JTextArea gracz;
    JTextArea przeciwnik;
    JTextArea tutorial;
    JTextArea faza;

    Przeciwnik przeciwnikT;
    Klient klientT;

    int wybranyRozmiar;

    boolean poziomo;
    boolean stawianie;
    boolean singlePlayer;
    boolean multiplayer;
    boolean serwer;

    Socket socket;
    ServerSocket server;

    String graczOstatniRuch;
    String przeciwnikOstatniRuch;

    RysujPlansze(){

        planszaGracz = new Plansza();
        planszaPrzeciwnik = new Plansza();

        wybranyRozmiar = 1;

        poziomo = false;
        singlePlayer = false;
        stawianie = true;
        multiplayer = false;
        serwer = false;

        addMouseListener(this);
        setLayout(null);

        poziomoButton = new JButton("Poziomo");
        add(poziomoButton);
        poziomoButton.addActionListener(this);

        wybierzJedenMaszt = new JButton("Jeden");
        add(wybierzJedenMaszt);
        wybierzJedenMaszt.addActionListener(this);

        wybierzDwaMaszt = new JButton("Dwa");
        add(wybierzDwaMaszt);
        wybierzDwaMaszt.addActionListener(this);

        wybierzTrzyMaszt = new JButton("Trzy");
        add(wybierzTrzyMaszt);
        wybierzTrzyMaszt.addActionListener(this);

        wybierzCzteryMaszt = new JButton("Cztery");
        add(wybierzCzteryMaszt);
        wybierzCzteryMaszt.addActionListener(this);


        single = new JButton("SinglePlayer");
        add(single);
        single.addActionListener(this);

        multi = new JButton("Multiplayer");
        add(multi);
        multi.addActionListener(this);

        reset = new JButton("Reset");
        add(reset);
        reset.addActionListener(this);

        wyjdz = new JButton("Wyjdź");
        add(wyjdz);
        wyjdz.addActionListener(this);

        Border border = BorderFactory.createBevelBorder(1,Color.lightGray,Color.blue);

        gracz = new JTextArea("Gracz zatopił "+planszaGracz.iloscZatopionych+" Statków");
        gracz.setBorder(border);
        add(gracz);

        przeciwnik = new JTextArea("Przeciwnik zatopił "+planszaPrzeciwnik.iloscZatopionych+" Statków");
        przeciwnik.setBorder(border);
        add(przeciwnik);

        graczOstatniRuch = "Gracz jeszcze się nie ruszył";
        przeciwnikOstatniRuch = "Przeciwnik jeszcze się nie ruszył";

    }


    @Override
    protected void paintComponent(Graphics g) {
        setBackground(Color.white);

        rysujPlanczeGracza(g);
        rysujPlanszePrzeciwnika(g);
        ustawPozycje();

        if(stawianie){
            if(poziomo)
                poziomoButton.setText("Poziomo");
            else
                poziomoButton.setText("Pionowo");
        }
        int graczSkutecznosc = (int)((float)planszaGracz.iloscTrafien / (float)planszaGracz.iloscStrzalow * 100);
        int przeciwnikSkutecznosc = (int)((float)planszaPrzeciwnik.iloscTrafien / (float)planszaPrzeciwnik.iloscStrzalow * 100);

        gracz.setText("Gracz zatopił "+planszaGracz.iloscZatopionych+" Statków\nSkuteczność: " + planszaGracz.iloscTrafien + "/"  + planszaGracz.iloscStrzalow + " " + graczSkutecznosc + "%\n"
        +graczOstatniRuch);
        przeciwnik.setText("Przeciwnik zatopił "+planszaPrzeciwnik.iloscZatopionych+" Statków\nSkuteczność: " + planszaPrzeciwnik.iloscTrafien + "/"  + planszaPrzeciwnik.iloscStrzalow + " " + przeciwnikSkutecznosc + "%\n"
        +przeciwnikOstatniRuch);

        wybierzJedenMaszt.setText("Jeden: "+ planszaGracz.listyStatkow[0].size());
        wybierzDwaMaszt.setText("Dwa: "+ planszaGracz.listyStatkow[1].size());
        wybierzTrzyMaszt.setText("Trzy: "+ planszaGracz.listyStatkow[2].size());
        wybierzCzteryMaszt.setText("Cztery: "+ planszaGracz.listyStatkow[3].size());

    }

    public void ustawPozycje(){
        poziomoButton.setBounds(0, getHeight() - getHeight()/10, getWidth()/5, getHeight()/10);
        wybierzJedenMaszt.setBounds(getWidth() - 4 * getWidth()/5, getHeight() - getHeight()/10, getWidth()/5, getHeight()/10);
        wybierzDwaMaszt.setBounds(getWidth() - 3 * getWidth()/5, getHeight() - getHeight()/10, getWidth()/5, getHeight()/10);
        wybierzTrzyMaszt.setBounds(getWidth() - 2 * getWidth()/5, getHeight() - getHeight()/10, getWidth()/5, getHeight()/10);
        wybierzCzteryMaszt.setBounds(getWidth() - getWidth()/5, getHeight() - getHeight()/10, getWidth()/5, getHeight()/10);

        single.setBounds(getWidth()/2 - 75, 10, 150, 20);
        multi.setBounds(getWidth()/2 - 75, 40, 150, 20);
        reset.setBounds(getWidth()/2 - 75, 70, 150, 20);
        wyjdz.setBounds(getWidth()/2 - 75, 160, 150, 20);

        gracz.setBounds(0, getHeight()/2 + 5, getHeight()/2 - 5, 60);
        przeciwnik.setBounds(getWidth() - (getHeight()/20) * 10, getHeight()/2 + 5, getHeight()/2 - 5, 60);
    }

    public void graczWygral(){
        int result = showConfirmDialog(this,
                "Wygrałeś czy chcesz grać dalej?",null, YES_NO_OPTION);
        if(result == YES_OPTION) {
            reset();
        }
        else
            System.exit(0);
        remove(result);

    }
    public void przeciwnikWygral(){

        int result = showConfirmDialog(null,
                "Przegrałeś czy chcesz grać dalej?",null, YES_NO_OPTION);
        if(result == YES_OPTION) {
            reset();
        }
        else
            System.exit(0);
        remove(result);
    }

    public boolean metodaPolaczenia(){
        int result = showConfirmDialog(this,
                "Hostujesz?",null, YES_NO_OPTION);
        if(result == YES_OPTION) {
            return true;
        }
        else
            return false;

    }

    public void rysujPlanczeGracza(Graphics g){
        if(planszaGracz.iloscStatkow==0)
            stawianie = false;
        planszaGracz.sprawdz();
        int dim;
        Graphics2D g2 = (Graphics2D) g;
        if(getHeight() <= getWidth())
            dim = getHeight()/20;
        else
            dim = getWidth()/20;
        planszaGracz.sprawdz();
        for(int i = 0;i<10;i++){
            for(int j = 0;j<10;j++){
                if(planszaGracz.planszaStatkow[i][j]!=null){
                    if(planszaGracz.planszaStatkow[i][j].life!=0)
                        g.setColor(Color.red);
                    else
                        g.setColor(Color.gray);
                }
                else if(stawianie && planszaGracz.moznaPostawicPoziomo[j][i] >= wybranyRozmiar && poziomo)
                    g.setColor(Color.green);
                else if(stawianie && planszaGracz.moznaPostawicPionowo[j][i] >= wybranyRozmiar && !poziomo)
                    g.setColor(Color.green);
                else
                    g.setColor(Color.white);
                g.fillRect( i*dim,j*dim,dim,dim);
                if(planszaGracz.czyPoleZaatakowane[i][j]) {
                    g.setColor(Color.black);
                    Line2D lin = new Line2D.Float( dim* i, j*dim, dim* (i+1), (j+1)*dim);
                    g2.draw(lin);
                    Line2D lin2 = new Line2D.Float( dim* i, (j+1)*dim,  dim* (i+1), j*dim);
                    g2.draw(lin2);
                }
            }

        }
        for(int i = 0; i <= 10;i++){
            g.setColor(Color.black);
            Line2D lin = new Line2D.Float(0, i*dim, 10*dim, i*dim);
            g2.draw(lin);
            Line2D lin2 = new Line2D.Float(i*dim, 0, i*dim, 10*dim);
            g2.draw(lin2);
        }

    }
    public void rysujPlanszePrzeciwnika(Graphics g){

        int dim;
        Graphics2D g2 = (Graphics2D) g;
        Ellipse2D.Double ellipse;

        if(getHeight() <= getWidth())
            dim = getHeight()/20;
        else
            dim = getWidth()/20;
        int start = getWidth() - dim * 10;

        for(int i = 0;i<10;i++){
            for(int j = 0;j<10;j++){


                if(planszaPrzeciwnik.planszaStatkow[i][j]!=null && planszaPrzeciwnik.czyPoleZaatakowane[i][j])
                    if(planszaPrzeciwnik.planszaStatkow[i][j].life!=0)
                        g.setColor(Color.red);
                    else
                        g.setColor(Color.gray);
                else
                    g.setColor(Color.white);
                g.fillRect( start + i*dim,j*dim,dim,dim);
                if(planszaPrzeciwnik.czyPoleZaatakowane[i][j]) {
                    g.setColor(Color.black);
                    Line2D lin = new Line2D.Float(start + dim* i, j*dim, start + dim* (i+1), (j+1)*dim);
                    g2.draw(lin);
                    Line2D lin2 = new Line2D.Float(start + dim* i, (j+1)*dim, start + dim* (i+1), j*dim);
                    g2.draw(lin2);
                }
            }

        }
        for(int i = 0; i <= 10;i++){
            g.setColor(Color.black);
            Line2D lin = new Line2D.Float(getWidth() - 10 * dim, i*dim, getWidth(), i*dim);
            g2.draw(lin);
            Line2D lin2 = new Line2D.Float(getWidth() - i*dim, 0, getWidth() - i*dim, 10*dim);
            g2.draw(lin2);
        }
    }


    @Override
    public void mouseClicked(MouseEvent e) {
        if(stawianie)
            postaw(e);
        else
            if(planszaGracz.ruch == 1)
                zaatakuj(e);
        repaint();
    }
    void postaw(MouseEvent e){
        int dim;
        int x = e.getX();
        int y = e.getY();

        if(getHeight() <= getWidth())
            dim = getHeight()/20;
        else
            dim = getWidth()/20;
        for(int i = 0;i<10;i++){
            for(int j=0;j<10;j++){
                if(( x >= dim * i &&  x <= dim * (i +1) ) && ( y >= dim * j && y <= dim * (j +1))){
                    if(planszaGracz.planszaStatkow[i][j]!=null)
                        System.out.println("Statek");
                    planszaGracz.dodajStatek(wybranyRozmiar,i,j,poziomo);
                }
            }
        }
    }
    void zaatakuj(MouseEvent e){
        int dim;
        int x = e.getX();
        int y = e.getY();

        if(getHeight() <= getWidth())
            dim = getHeight()/20;
        else
            dim = getWidth()/20;
        int start = getWidth() - dim * 10;
        for(int i = 0;i < 10;i++){
            for(int j = 0 ;j < 10;j++){
                if(( x >= start + dim * i &&  x <= start + dim * (i +1) ) && ( y >= dim * j && y <= dim * (j +1))){
                    String temp = "brak";
                    if(planszaGracz.ruch==1)
                        temp = planszaGracz.atak(i,j,planszaPrzeciwnik);
                    if(!temp.equals("brak") && multiplayer){
                        wyslij(i,j);
                    }
                    graczOstatniRuch = temp;
                }
            }
        }
    }
    void wyslij(int x, int y){
        DataOutputStream out = null;
        try {
           out = new DataOutputStream(socket.getOutputStream());
            x = x*10;
            x = x + y;
            System.out.println(x);
            out.writeInt(x);
            out.flush();
        } catch (IOException e) {
            e.printStackTrace();
        }

    }

    void reset()  {
        planszaGracz = new Plansza();
        planszaPrzeciwnik = new Plansza();
        wybranyRozmiar = 1;

        if(multiplayer){
            try {
                if(serwer)
                    server.close();
                else
                    socket.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        graczOstatniRuch = "Gracz jeszcze się nie ruszył";
        przeciwnikOstatniRuch = "Przeciwnik jeszcze się nie ruszył";

        poziomo = false;
        singlePlayer = false;
        stawianie = true;
        multiplayer = false;

        repaint();
    }

    @Override
    public void mousePressed(MouseEvent mouseEvent) {

    }

    @Override
    public void mouseReleased(MouseEvent mouseEvent) {

    }

    @Override
    public void mouseEntered(MouseEvent mouseEvent) {

    }

    @Override
    public void mouseExited(MouseEvent mouseEvent) {

    }

    @Override
    public void actionPerformed(ActionEvent actionEvent) {
        Object source = actionEvent.getSource();
        if(source == poziomoButton)
        {
            poziomo = !poziomo;
            if(poziomo)
                poziomoButton.setText("Poziomo");
            else
                poziomoButton.setText("Pionowo");
        }
        if(source == wybierzJedenMaszt)
            wybranyRozmiar = 1;

        if(source == wybierzDwaMaszt)
            wybranyRozmiar = 2;

        if(source == wybierzTrzyMaszt)
            wybranyRozmiar = 3;

        if(source == wybierzCzteryMaszt)
            wybranyRozmiar = 4;
        if(source == reset)
            reset();
        if(source == single && !singlePlayer){
            if(planszaGracz.iloscStatkow != 0)
                System.out.println("Ustaw statki");
            else{
                singlePlayer = true;
                przeciwnikT = new Przeciwnik(planszaPrzeciwnik,planszaGracz,this);
                przeciwnikT.start();
            }
        }
        if(source == wyjdz)
            System.exit(0);


        if(source == multi && !multiplayer){
            if(planszaGracz.iloscStatkow != 0)
                System.out.println("Ustaw statki");
            else{

                serwer = metodaPolaczenia();

                multiplayer = true;

                if(serwer){
                    multiplayer = serwer();
                }
                else{
                    multiplayer = klient();
                    if(multiplayer)
                        planszaGracz.ruch = 2;
                }
                if(multiplayer){
                    klientT = new Klient(planszaPrzeciwnik,planszaGracz,socket,this);
                    klientT.start();
                }
            }
        }

        System.out.println(wybranyRozmiar);
        repaint();
    }
    boolean serwer(){
        try {
            server = new ServerSocket(5000);
            InetAddress adres = InetAddress.getLocalHost();
            String hostIP = adres.getHostAddress() ;
            String hostName = adres.getHostName();

            showMessageDialog(this, "Podziel się swoją nazwą z klientem: "+hostIP+"\nTwoja Nazwa: "+hostName,"Nazwa",2);
            socket =  new Socket();
            socket.setSoTimeout(100);
            socket = server.accept();

            OutputStream out = socket.getOutputStream();
            ObjectOutputStream objOut = new ObjectOutputStream(out);
            objOut.writeObject(planszaGracz);

            objOut.flush();

            InputStream in = socket.getInputStream();
            ObjectInputStream objIn = new ObjectInputStream(in);

            planszaPrzeciwnik = (Plansza) objIn.readObject();

        } catch (IOException | ClassNotFoundException | NullPointerException e) {
            return false;
        }
        return true;
    }
    boolean klient(){
        try {

            socket = new Socket("localhost", 5000);
            socket.setSoTimeout(10000);

            InputStream in = socket.getInputStream();
            ObjectInputStream objIn = new ObjectInputStream(in);

            planszaPrzeciwnik = (Plansza) objIn.readObject();

            OutputStream out = socket.getOutputStream();
            ObjectOutputStream objOut = new ObjectOutputStream(out);
            objOut.writeObject(planszaGracz);
            objOut.flush();

        } catch (IOException | ClassNotFoundException e) {
            return false;
        }
        return true;
    }

}