package StatkiKlient;

import java.io.Serializable;

public class Statek implements Serializable {

    int life;
    int rozmiar;
    boolean dodane;

    Statek(int rozmiar){

        this.life = rozmiar;
        this.rozmiar = rozmiar;
        dodane = false;
    }
}
