package StatkiKlient;

import javax.swing.*;
import java.awt.*;
import java.util.concurrent.Flow;

public class Frame extends JFrame {

    public Frame() {
        super("Rysowanie");

        setPreferredSize(new Dimension(800,600));
        setResizable(false);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        //setLayout(new GridLayout());

        JPanel plansza = new Plansza();
        JPanel plansza2 = new Plansza();
        add(plansza);
        add(plansza2);

        pack();


        setVisible(true);


    }

}
