package StatkiKlient;
public class Statek {

    int life;
    int rozmiar;
    boolean dodane;

    Statek(int rozmiar){

        this.life = rozmiar;
        this.rozmiar = rozmiar;
        dodane = false;
    }
}
